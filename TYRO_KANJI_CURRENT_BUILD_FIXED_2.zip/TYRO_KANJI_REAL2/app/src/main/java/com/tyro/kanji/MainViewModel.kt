package com.tyro.kanji

import android.app.Application
import androidx.glance.appwidget.updateAll
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tyro.kanji.data.*
import com.tyro.kanji.widget.KanjiWidget
import com.tyro.kanji.widget.WidgetScheduler
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val db = TyroDatabase.get(app)
    private val dao = db.kanjiDao()
    private val prefs = app.getSharedPreferences("tyro_settings", 0)

    val kanji = dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val mastered = dao.mastered().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    private val _selectedIds = MutableStateFlow(loadSelectedIds())
    private val _jlptLevel = MutableStateFlow(prefs.getString("jlpt_level", "ALL") ?: "ALL")
    val jlptLevel = _jlptLevel.asStateFlow()
    val selectedIds = _selectedIds.asStateFlow()

    val due = combine(dao.observeAll(), _selectedIds) { all, selected ->
        all.filter { it.id in selected }
    }.flatMapLatest { chosen ->
        val now = System.currentTimeMillis()
        if (chosen.isEmpty()) flowOf(0) else flow {
            var count = 0
            chosen.forEach { k -> if ((dao.progress(k.id)?.repetitions ?: 0) > 0 && (dao.progress(k.id)?.dueAt ?: Long.MAX_VALUE) <= now) count++ }
            emit(count)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val _query = MutableStateFlow("")
    val query = _query.asStateFlow()
    val filtered = combine(dao.observeAll(), _query) { all, q ->
        if (q.isBlank()) all else all.filter {
            it.kanji.contains(q) || it.hiragana.contains(q) || it.romaji.contains(q) || it.meaning.contains(q, true)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _shuffle = MutableStateFlow(prefs.getBoolean("shuffle", true))
    val shuffle = _shuffle.asStateFlow()
    private val _refreshToken = MutableStateFlow(0)
    val refreshToken = _refreshToken.asStateFlow()
    private val _theme = MutableStateFlow(prefs.getString("theme", "system") ?: "system")
    val theme = _theme.asStateFlow()

    init { viewModelScope.launch { DatabaseSeeder.seed(db); restoreImportedKanji(); ensureSelection(); WidgetScheduler.schedule(app); NotificationScheduler.schedule(app) } }

    private fun loadSelectedIds(): Set<Int> = prefs.getString("selected_ids", null)
        ?.split(',')?.mapNotNull { it.toIntOrNull() }?.toSet() ?: emptySet()

    private suspend fun ensureSelection() {
        if (_selectedIds.value.isEmpty()) {
            val all = dao.observeAll().first()
            val official = all.filter { it.jlpt == "N5" || it.jlpt == "N4" }
            if (official.isNotEmpty()) setSelectedIds(official.map { it.id }.toSet())
        }
    }

    fun importKanji(raw: String): Int {
        val lines = raw.lines().map { it.trim() }.filter { it.isNotBlank() }
        if (lines.isEmpty()) return 0
        val importedIds = mutableListOf<Int>()
        viewModelScope.launch {
            val all = dao.observeAll().first()
            val existingChars = all.map { it.kanji }.toSet()
            var nextId = prefs.getInt("next_custom_id", 10001)
            val newItems = mutableListOf<KanjiEntity>()

            for (line in lines) {
                val normalized = line.replace("–", "—").trim()
                val parts = normalized.split(Regex("\\s*—\\s*|\\s*\\|\\s*"), limit = 3)
                    .map { it.trim() }.filter { it.isNotBlank() }

                // Supported forms:
                // 保 protect
                // 保 — protect
                // 保 — ほ — protect
                // 保 | ほ | protect
                val firstField = parts.firstOrNull().orEmpty()
                val char = firstField.firstOrNull()?.toString() ?: continue
                if (char.isBlank() || existingChars.contains(char) || newItems.any { it.kanji == char }) continue

                val kanaRegex = Regex("[ぁ-ゖァ-ヺー]")
                val latinMeaningRegex = Regex("[A-Za-z]")
                var reading = "—"
                var meaning = "Custom Kanji"

                if (parts.size >= 3) {
                    reading = parts[1]
                    meaning = parts[2]
                } else if (parts.size == 2) {
                    val second = parts[1]
                    if (kanaRegex.containsMatchIn(second)) {
                        reading = second
                        meaning = "Custom Kanji"
                    } else if (latinMeaningRegex.containsMatchIn(second)) {
                        meaning = second
                    }
                } else {
                    val remainder = firstField.drop(char.length).trim()
                    if (remainder.isNotBlank() && latinMeaningRegex.containsMatchIn(remainder)) meaning = remainder
                    else {
                        val whitespace = normalized.trim().split(Regex("\\s+"), limit = 2)
                        if (whitespace.size == 2 && latinMeaningRegex.containsMatchIn(whitespace[1])) meaning = whitespace[1].trim()
                    }
                }

                val item = KanjiEntity(
                    id = nextId++,
                    kanji = char,
                    hiragana = reading,
                    romaji = "",
                    meaning = meaning
                )
                newItems += item
                importedIds += item.id
            }
            if (newItems.isNotEmpty()) {
                dao.insertAll(newItems)
                prefs.edit().putInt("next_custom_id", nextId).apply()
                val selected = _selectedIds.value.toMutableSet().apply { addAll(importedIds) }
                setSelectedIds(selected)
                updateWidget()
            }
        }
        return lines.size
    }

    private suspend fun restoreImportedKanji() {
        // Imported Kanji are persisted directly in Room. This method intentionally stays
        // lightweight so existing installs keep their original 307 entries untouched.
    }

    fun deleteImportedKanji(id: Int) {
        if (id < 10000) return
        viewModelScope.launch {
            dao.deleteById(id)
            val next = _selectedIds.value.toMutableSet().apply { remove(id) }
            setSelectedIds(next)
            updateWidget()
        }
    }

    fun setQuery(q: String) { _query.value = q }

    fun setSelected(id: Int, selected: Boolean) {
        val next = _selectedIds.value.toMutableSet().apply { if (selected) add(id) else remove(id) }
        setSelectedIds(next)
    }

    fun selectAll() { viewModelScope.launch { setSelectedIds(dao.observeAll().first().map { it.id }.toSet()) } }
    fun clearSelection() { setSelectedIds(emptySet()) }

    /** Select exactly the N5, N4, or combined 320-kanji PDF catalog. */
    fun setJlptLevel(level: String) {
        val normalized = when (level) { "N5", "N4" -> level; else -> "ALL" }
        _jlptLevel.value = normalized
        prefs.edit().putString("jlpt_level", normalized).putInt("widget_index", 0).commit()
        viewModelScope.launch {
            val all = dao.observeAll().first()
            val ids = when (normalized) {
                "N5" -> all.filter { it.jlpt == "N5" }
                "N4" -> all.filter { it.jlpt == "N4" }
                else -> all.filter { it.jlpt == "N5" || it.jlpt == "N4" }
            }.map { it.id }.toSet()
            setSelectedIds(ids)
            updateWidget()
        }
    }

    private fun setSelectedIds(ids: Set<Int>) {
        _selectedIds.value = ids
        prefs.edit().putString("selected_ids", ids.sorted().joinToString(",")).putInt("widget_index", 0).apply()
        _refreshToken.value++
        updateWidget()
    }

    fun setShuffle(enabled: Boolean) {
        _shuffle.value = enabled
        prefs.edit().putBoolean("shuffle", enabled).apply()
        _refreshToken.value++
    }

    fun setTheme(value: String) {
        _theme.value = value
        prefs.edit().putString("theme", value).apply()
    }

    fun refreshStudy() { _refreshToken.value++ }

    fun studyOrder(all: List<KanjiEntity>): List<KanjiEntity> {
        val selected = all.filter { it.id in _selectedIds.value }
        return if (_shuffle.value) selected.shuffled(Random(_refreshToken.value + 1000)) else selected
    }

    fun progress(id: Int) = flow { emit(dao.progress(id) ?: ProgressEntity(id)) }
    fun isMastered(id: Int) = flow { emit((dao.progress(id)?.mastery ?: 0) >= 5) }

    fun setMastered(id: Int, mastered: Boolean) = viewModelScope.launch {
        val old = dao.progress(id) ?: ProgressEntity(id)
        val now = System.currentTimeMillis()
        dao.saveProgress(old.copy(
            mastery = if (mastered) 5 else 0,
            intervalDays = if (mastered) max(old.intervalDays, 30) else old.intervalDays,
            dueAt = if (mastered) now + 365L * 86_400_000L else now,
            lastReviewed = now
        ))
        _refreshToken.value++
    }

    fun favorite(id: Int, value: Boolean) = viewModelScope.launch {
        dao.saveProgress((dao.progress(id) ?: ProgressEntity(id)).copy(favorite = value))
    }

    fun review(id: Int, rating: Int) = viewModelScope.launch {
        val old = dao.progress(id) ?: ProgressEntity(id)
        val now = System.currentTimeMillis()
        val interval = when (rating) {
            0 -> 0
            1 -> max(1, if (old.intervalDays == 0) 1 else old.intervalDays * 2)
            2 -> max(2, if (old.intervalDays == 0) 3 else old.intervalDays * 3)
            else -> max(4, if (old.intervalDays == 0) 7 else old.intervalDays * 4)
        }
        val mastery = if (rating == 0) max(0, old.mastery - 1) else min(5, old.mastery + if (rating >= 2) 1 else 0)
        dao.saveProgress(old.copy(
            intervalDays = interval,
            dueAt = now + interval * 86_400_000L,
            repetitions = old.repetitions + 1,
            correct = old.correct + if (rating >= 2) 1 else 0,
            wrong = old.wrong + if (rating == 0) 1 else 0,
            mastery = mastery,
            lastReviewed = now
        ))
    }

    fun saveWidgetFont(font: String) { prefs.edit().putString("widget_font", font).commit(); updateWidget() }
    fun saveWidgetSize(size: Int) { prefs.edit().putInt("widget_size", size.coerceIn(28, 96)).commit(); updateWidget() }
    fun saveWidgetColor(color: String) { prefs.edit().putString("widget_color", color).commit(); updateWidget() }
    fun saveWidgetAutoRefresh(minutes: Int) {
        prefs.edit().putInt("widget_auto_refresh", minutes).commit()
        WidgetScheduler.schedule(getApplication())
        updateWidget()
    }

    private fun updateWidget() {
        viewModelScope.launch { KanjiWidget().updateAll(getApplication<Application>()) }
    }
}
